<?php
	die();
?><pre>Array
(
    [currentFolderPath] => ../../../../uploaded/
    [new_folder] => Add
)
</pre>

19/Mar/2011 07:41:56
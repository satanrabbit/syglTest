<?php die(); ?>
gc start at 11/Nov/2011 14:49:52
